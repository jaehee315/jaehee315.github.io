---
layout: list
title: Hydejack
slug: hydejack
menu: true
order: 2
description: >
  Hydejack is a pretentious two-column [Jekyll](http://jekyllrb.com/) theme, stolen by
  [@qwtel](https://twitter.com/qwtel) from [Hyde](http://hyde.getpoole.com).
  You could say it was.. [hydejacked](http://media3.giphy.com/media/makedRIckZBW8/giphy.gif).
  Open `_featured_tags/hydejack.md` to edit this text.
---
